void GBCC(int , int , double* , double* , int , int , int* , double* );
void GBCC(int , int , double* , double* , double* , int , int , int* , double* );

void GBCR(int , int , double* , double* , int , int* , double* );
void GBCR(int , int , double* , double* , double* , int , int* , double* );

void GBCP(int , int , double* , double* , int , int , int* , double* );
void GBCP(int , int , double* , double* , double* , int , int , int* , double* );
