#include <Rcpp.h>
#include "node_cuts.h"
#include "quickie.h"
#include <cmath>
using namespace Rcpp;

// [[Rcpp::export]]
List best_cut_node(char method, NumericMatrix Data, NumericVector Labels, NumericVector W,int minleaf, int num_labels) {

  int M=Data.nrow();
  int N=Data.ncol();
  int *bcvar = new int;
  double *bcval = new double;
  
  //std::vector<double> Data1(Data.size());
  //std::vector<double> Labels1(M);
  double Data1[Data.size()];
  double Labels1[M];
  
  for(int i=0;i<M;i++){
    for(int j=0;j<N;j++){
      Data1[i+j*M]=Data(i,j);
    }
    Labels1[i]=Labels[i];
  }
  
 
 if (W[0]==1){
   switch (method){
   case 'c':
     GBCC(M, N, Labels1, Data1, minleaf, num_labels, bcvar, bcval);
     break;
   case 'g':
     GBCP(M, N, Labels1, Data1, minleaf, num_labels, bcvar, bcval);
     break;
   case 'r':
     GBCR(M, N, Labels1, Data1, minleaf, bcvar, bcval);
     break;
   }
   
 }else{
   
   double W1[M];
   for(int k=0;k<M;k++){
     W1[k]=W[k];
   }
   
   switch (method){
   case 'c':
     GBCC(M, N, Labels1, Data1, W1, minleaf, num_labels, bcvar, bcval);
     break;
   case 'g':
     GBCP(M, N, Labels1, Data1, W1, minleaf, num_labels, bcvar, bcval);
     break;
   case 'r':
     GBCR(M, N, Labels1, Data1, W1, minleaf, bcvar, bcval);
     break;
   }
 }

  List bestCut = List::create(
    _["BestCutVar"]= *bcvar, 
    _["BestCutVal"]= *bcval);
  
  return(bestCut);
}

