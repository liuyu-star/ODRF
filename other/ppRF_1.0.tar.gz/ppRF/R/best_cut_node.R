#' find  best split variable and node.
#'
#' @param       X       : an n by d numeric matrix (preferable) or data frame.
#' 
#' @param       y       : a n vector.
#' 
#' @param       method       : the criterion used for splitting the nodes
#'                           'g' : gini impurity index (classification)
#'                           'c' : information gain (classification)
#'                           'r' : squared error (regression)
#'
#' @param       MinLeaf      : the minimum amount of samples in a leaf
#'
#' @param       weights      : a vector of values which weigh the samples when considering a split
#'
#' @param       numLabels    : the number of categories
#' 
#' 
#' @return a list which contains:
#' \itemize{
#' \item BestCutVar: the best split variable
#' \item BestCutVal: the best split point for the best split variable.
#' \item MinVal: Each variable corresponds to the min gini impurity index(method='g'), information gain(method='c') and squared error(method='r')
#' }
#'
#' @useDynLib ppRF
#' @import Rcpp
#' 
#' @export
#' 
#' @examples
#' ### Find the best split variable ###
#' library(ppRF)
#' X=as.matrix(iris[, 1:4])
#' y=iris[[5L]]
#'
#' bestcut=bestCut(X,y,method='c')
#' 
bestCut <- function(X, y, method='c', weights=1, MinLeaf=ifelse(method=='r',5,1),
                          numLabels=ifelse(method=='r',0,length(unique(y)))) {
  .Call(`_ppRF_best_cut_node`, method, X, y, weights, MinLeaf, numLabels)
}

