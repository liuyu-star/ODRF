#' @method print ppRF
#' @export
print.ppRF <-function(y, ...) {
  cat("\nCall:\n", deparse(y$call), "\n")
  cat("               Type of projection pursuit random forest: ", 
      ifelse(y$method=="r","regression","classification"), "\n", sep="")
  cat("                                        Number of trees: ", y$tree$ntrees, "\n",sep="")
  #cat("No. of variables tried at each split: ", x$mtry, "\n\n", sep="")
    if(y$forest$numOOB>0){
  cat("                             OOB estimate of error rate: ",round(OOBErr(y)*100,2), "%\n", sep="")
      if(y$method!="r") {    
  cat("Confusion matrix:\n")
  print(y$XConfusionMat)
      }
    }else{
  cat("The number of OOBs is 0")
    }
}
