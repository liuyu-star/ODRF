#' carPPtree Prediction
#'
#' Prediction a decision tree based on an input matrix and class vector.  This is the main function in the ppRF1 package.
#'
#' @param Xnew an n by d numeric matrix (preferable) or data frame. The rows correspond to observations and columns correspond to features.
#' @return carPPtree Prediction
#'
#' @useDynLib ppRF
#' @import Rcpp
#' 
#' @export
#' 
#' @examples
#' ### Train RerF on numeric data ###
#' library(rerf)
#' forest <- RerF1(as.matrix(iris[, 1:4]), iris[[5L]], num.cores = 1L)
#'
#' ### Train RerF on one-of-K encoded categorical data ###
#' df1 <- as.data.frame(Titanic)
#' nc <- ncol(df1)
#' df2 <- df1[NULL, -nc]
#' for (i in which(df1$Freq != 0L)) {
#'   df2 <- rbind(df2, df1[rep(i, df1$Freq[i]), -nc])
#' }
## @rdname predict#'  #' @aliases predict_ppCART #' @method predict ppCART
varImportance=function(ppForest){
  Levels=ppForest$Levels
  method=ppForest$method
  X=ppForest$data$X
  y=ppForest$data$y
  ntrees=ppForest$tree$ntrees
  n=length(y);p=ncol(X)
  
  runOOBErr=function(trees,...){
    oobErrs=rep(0,p+1)
    for (j in 1:(p+1)) {
      OOBindx=trees$OOBindx
      if(length(OOBindx)>0){
        if(j==1){
          Xi=X
        }else{
          Xi=X[OOBindx,]
          Xi[,j-1]=Xi[sample(n),j-1]
        }
        pred <- predict_ppCART(Xi,trees)
        if(tolower(method)%in%c('c','g')){
          oobErr=mean(pred!=Levels[y[OOBindx]]);
        }else{
          oobErr=mean((pred-y[OOBindx])^2);
        }
        
      }else{
        oobErr=1
      }
      
      oobErrs[j]=oobErr
      oobErrs[j]=(oobErrs[j]-oobErrs[1])^2
    }
  }
  
  oobErrVar=sapply(ppForest$ppTrees,runOOBErr)[-1,]
  oobErrVar=rowMeans(oobErrVar)
  varimport=cbind(var=seq(p),value=oobErrVar)

  return(varimport[order(oobErrVar,decreasing = T),])
}   
